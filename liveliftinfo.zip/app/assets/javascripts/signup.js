$(document).ready(function() {
  $('#info-modal').modal('show');
});