module WebcamsHelper
end
