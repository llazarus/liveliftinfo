class Avalanche < ApplicationRecord
end
