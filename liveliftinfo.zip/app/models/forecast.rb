class Forecast < ApplicationRecord
end
