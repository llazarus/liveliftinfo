class AboutController < ApplicationController
  def index
  end
end
